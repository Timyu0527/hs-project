#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <stdlib.h>

using namespace std;

int headx=11,heady=11;
int foodx=rand()%19+1,foody=rand()%19+1;
const int h=21,w=21;
int key;
int score=0;
int Long;
int bodyx[26],bodyy[26];

enum eDirection{UP,DOWN,LEFT,RIGHT};
eDirection dir;
bool GameOver=false;

void Draw();
void Move();
void Turn();
void Food();



int main()
{
	system("color 0A");
	char ch;
	char difficulty;
    cout<<"�Ы�S�}�l�C��"<<endl;
	cin>>ch;
	switch(ch)
	{
		case's':
			system("cls");
			cout<<"�п������"<<endl;
			cout<<"1.²��"<<endl;
			cout<<"2.���q"<<endl;
			cout<<"3.�x��"<<endl;
			cin>>difficulty;
	    switch(difficulty)
	    {
	    	case '1':
	    		while(!GameOver)
	            {
	            	system("color 0A");
	            	Turn();
	                Draw();
	                Move();
	                Food();
	                Sleep(100);
	                cout<<"score:"<<score<<endl;
                    if(heady==h||heady==1||headx==w||headx==1)
	                {
	                    system("cls");
    	                GameOver=true;
    	                cout<<"Game Over"<<endl;
    	                cout<<"score:"<<score<<endl;
	                }
	                if(Long==15)
	                {
	                    system("cls");
	    	            GameOver=true;
	    	            cout<<"You Win"<<endl;
	    	            cout<<"score:"<<score<<endl;
		            }
                }
            case'2':
	    		while(!GameOver)
	            {
	            	system("color 0A");
	            	Turn();
	                Draw();
	                Move();
	                Food();
	                Sleep(50);
	                cout<<"score:"<<score<<endl;
                    if(heady==h||heady==1||headx==w||headx==1)
	                {
	                    system("cls");
    	                GameOver=true;
    	                cout<<"Game Over"<<endl;
    	                cout<<"score:"<<score<<endl;
	                }
	                if(Long==15)
	                {
	                    system("cls");
	    	            GameOver=true;
	    	            cout<<"You Win"<<endl;
	    	            cout<<"score:"<<score<<endl;
		            }
                }
            case '3':
	    		while(!GameOver)
	            {
	            	system("color 0A");
	            	Turn();
	                Move();
	                Draw();
	                Food();
	                cout<<"score:"<<score<<endl;
                    if(heady==h||heady==1||headx==w||headx==1)
	                {
	                    system("cls");
    	                GameOver=true;
    	                cout<<"Game Over"<<endl;
    	                cout<<"score:"<<score<<endl;
	                }
	                if(Long==15)
	                {
	                    system("cls");
	    	            GameOver=true;
	    	            cout<<"You Win"<<endl;
	    	            cout<<"score:"<<score<<endl;
		            }
                }
	    }
	system("pause");
   }
}


void Draw()
{
	int i;
	int j;
	system("cls");
	for(i=1;i<=h;i++)
	{
		for(j=1;j<=w;j++)
		{
			if((i==1&&j==1)||(i==1&&j==w)||(i==h&&j==1)||(i==h&&j==w))
			{
				cout<<"[]";
			}else if(i!=1&&i!=h&&j==1)
			{
				cout<<"||";
			}else if(i!=1&&i!=h&&j==w)
			{
				cout<<"||";
			}else if(i==1&&j!=1&&j!=w)
			{
				cout<<"==";
			}else if(i==h&&j!=1&&j!=w)
			{
				cout<<"==";
			}else if(i==heady&&j==headx)
			{
				cout<<"�i";
			}else if(i==foody&&j==foodx)
			{
				cout<<"��";
			}else
			{
			    bool print=false;
				for(int k=0;k<Long;k++)
				{
					if(bodyx[k]==j&&bodyy[k]==i)
					{
						cout<<"��";
						print=true;
					}
				}
				if(!print)
					{
						cout<<"  ";
					}
			}
		}
		cout<<endl;
	}
}
void Turn()
{
	int i;
	for(i=1;i<=25;i++)
	{
	if(kbhit())
	{
		 key=getch();
    switch(key)
	{
     case 0x48: // UP
     if(dir!=DOWN)
      dir=UP;
     break;
     case 0x50: // DOWN
     if(dir!=UP)
      dir=DOWN;
     break;
     case 0x4D: // Right
     if(dir!=LEFT)
      dir=RIGHT;
     break;
     case 0x4B: // Left
     if(dir!=RIGHT)
      dir=LEFT;
     break;
     }
	}
}
}
void Move()
{
	int prevx = bodyx[0];
    int prevy = bodyy[0];
    int prev2x, prev2y;
    bodyx[0] = headx;
    bodyy[0] = heady;
    for (int i=1;i<Long;i++)
    {
        prev2x = bodyx[i];
        prev2y = bodyy[i];
        bodyx[i] = prevx;
        bodyy[i] = prevy;
        prevx = prev2x;
        prevy = prev2y;
    }
	switch(dir)
	{
		case UP:
			heady--;
			break;
		case DOWN:
			heady++;
			break;
		case LEFT:
			headx--;
			break;
		case RIGHT:
			headx++;
			break;
	}
	for(int i=0;i<Long;i++)
    {
    	if(bodyx[i]==headx&&bodyy[i]==heady)
		{
			GameOver=true;
    	    cout<<"Game Over"<<endl;
		}
	}
}
void Food()
{
	if(headx==foodx&&heady==foody)
	{
		score++;
		foodx=rand()%19+1;
		foody=rand()%19+1;
		Long++;
	}

}
