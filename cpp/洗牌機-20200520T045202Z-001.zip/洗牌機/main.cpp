#include <iostream>

using namespace std;
int n,up,down,mode,number,a=0,b=0,c=0,d=1;
int cardin[100000],cardout1[100000],card[100000],cardout2[100000],journey[100000];
bool same=false;
void Setup();
void Shuffle();
void Determination();
void Out();
void Position();
void DovetailShuffle();
int main()
{
	cout<<"�п�J�@�ƵP���i�ơG";
	while(cin>>n)
	{
		cout<<"�п�J���W�~���P�ơG";
		cin>>up;
		cout<<"�п�J���U�~���P�ơG";
		cin>>down;
		cout<<endl;
		cout<<"1.�~���_�쪬"<<endl;
		cout<<"2.�@���~�P��b��쪺�P"<<endl;
		cout<<"3.�@�i�P���ȳ~"<<endl;
		cout<<"4.�@���~�P��b��쪺�P(�F�����~�P)"<<endl;
		cout<<"5.�~���_�쪬(�F�����~�P)"<<endl;
		cout<<"6.�@�i�P���ȳ~(�F�����~�P)"<<endl<<endl;
		cout<<"�п�J�Q�n���Ҧ��G";
		cin>>mode;
		switch(mode)
		{
			case 1:
				Setup();
				Shuffle();
				Determination();
				cout<<c<<endl;
				break;
			case 2:
				Setup();
				Shuffle();
				Out();
				Position();
				break;
			case 3:
				cout<<"�п�J�@�i�P���s���G";
				cin>>number;
				Setup();
				Shuffle();
				Determination();
				Out();
				break;
			case 4:
				Setup();
				DovetailShuffle();
				Out();
				Position();
				break;
			case 5:
				Setup();
				DovetailShuffle();
				Determination();
				cout<<c<<endl;
				break;
			case 6:
				cout<<"�п�J�@�i�P���s���G";
				cin>>number;
				Setup();
				DovetailShuffle();
				Determination();
				Out();
				break;
		}
	}
	return 0;
}
void Setup()
{
	for(int i=0;i<n;i++)
	{
		cardin[i]=i+1;
		card[i]=i+1;
	}
}
void Shuffle()
{
	a=0,b=0;
	for(int i=0;i<n;i+=down+up)
	{
		for(int j=0;j<up;j++)
		{
			if(i+j<n)
			{
				cardout1[a]=cardin[i+j];
				a++;
			}
		}
	}
	for(int i=0;i<n;i+=down+up)
	{
		for(int j=0;j<down;j++)
		{
			if(i+j+up<n)
			{
				cardout2[b]=cardin[i+up+j];
				b++;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		if(i<a)
		{
			cardin[i]=cardout1[a-1-i];
		}else
		{
			cardin[i]=cardout2[i-a];
		}
	}
	c++;
	if(mode==3)
	{
		journey[0]=number;
		for(int i=0;i<n;i++)
		{
			if(cardin[i]==number)
			{
				journey[d]=i+1;
				d++;
			}
		}
	}
}
void Determination()
{
	while(same==false)
	{
		same=true;
		if(mode==6 || mode==5 )
		{
			DovetailShuffle();
		}else if(mode==3 || mode==1)
		{
			Shuffle();
		}
		for(int i=0;i<n;i++)
		{
			if(card[i]!=cardin[i])
			{
				same=false;
			}
		}
	}	
}
void Out()
{
	if(mode==3 || mode==6)
	{
		for(int i=0;i<d;i++)
		{
			if(i==d-1)
			{
				cout<<journey[i]<<endl;
			}else
			{
				cout<<journey[i]<<"��";
			}
		}
		cout<<"�`���Ƭ��G"<<d<<endl;
	}else
	{
		for(int i=0;i<n;i++)
		{
			cout<<cardin[i]<<endl;
		}
		cout<<"========"<<endl;
	}
}
void Position()
{
	for(int i=0;i<n;i++)
	{
		if(cardin[i]==card[i])
		{
			cout<<cardin[i]<<" ";
		}
	}
	cout<<endl;
}
void DovetailShuffle()
{
	a=0,b=0;
	for(int i=0;i<n;i++)
	{
		if(i<n/2)
		{
			cardout1[i]=cardin[i];
		}else
		{
			cardout2[i-n/2]=cardin[i];
		}
	}
	for(int i=0;i<n;i+=down+up)
	{
		for(int j=0;j<up;j++)
		{
			if(i+j<n)
			{
				cardin[i+j]=cardout1[a];
				a++;
			}
		}
		for(int j=0;j<down;j++)
		{
			if(i+up+j<n)
			{
				cardin[i+up+j]=cardout2[b];
				b++;
			}
		}
	}
	c++;
	if(mode==6)
	{
		journey[0]=number;
		for(int i=0;i<n;i++)
		{
			if(cardin[i]==number)
			{
				journey[d]=i+1;
				d++;
			}
		}
	}
}
